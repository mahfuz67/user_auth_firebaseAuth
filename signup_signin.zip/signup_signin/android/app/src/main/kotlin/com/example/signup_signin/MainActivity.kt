package com.example.signup_signin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
